基于 commit：4741d46ba9cd6159c5d853eb9d6fc48b4bfa2b1a

内部的 DummyDll 为 TCAA 游戏 dump。